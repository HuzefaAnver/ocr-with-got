import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

import numpy as np
import cv2
from datetime import datetime
import argparse
import torch
from GOT.utils.conversation import conv_templates, SeparatorStyle
from GOT.utils.utils import disable_torch_init
from transformers import AutoTokenizer, AutoModelForCausalLM, CLIPVisionModel, CLIPImageProcessor, StoppingCriteria,TextStreamer
from GOT.model import *
from GOT.utils.utils import KeywordsStoppingCriteria
from PIL import Image
import requests
from io import BytesIO
from GOT.model.plug.blip_process import BlipImageEvalProcessor
from GOT.demo.process_results import punctuation_dict, svg_to_html
import string

DEFAULT_IMAGE_TOKEN = "<image>"
DEFAULT_IMAGE_PATCH_TOKEN = '<imgpad>'

DEFAULT_IM_START_TOKEN = '<img>'
DEFAULT_IM_END_TOKEN = '</img>'


translation_table = str.maketrans(punctuation_dict)

def format_date(s):
    if s.startswith("2024"):
        formatted_date = s[:4] + '-' + s[4:6] + '-' + s[6:]
        return formatted_date
    elif s.endswith("2024"):
        formatted_date = s[:2] + '-' + s[2:4] + '-' + s[4:]
        return formatted_date

def format_time(s):
    formatted_time = s[:2] + ':' + s[2:4] + ':' + s[4:6]
    return formatted_time

def load_image(frame):
    if isinstance(frame, np.ndarray):
        image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    else:
        raise ValueError("Input must be a NumPy array (frame from cv2).")
    
    return image

def processing(outputs):
    digits_only = ''.join([char for char in outputs if char.isdigit()])
    if len(digits_only) == 14:
        date = digits_only[:8]
        time = digits_only[-6:]
        date = format_date(date)
        # print("date: ", date)
        time = format_time(time)
        # print("time: ", time)
        return f'{date} {time}'
    else:
        return "Invalid Length"

def eval_model(args,model, img_np, type, device):

    image_processor = BlipImageEvalProcessor(image_size=1024)
    image_processor_high =  BlipImageEvalProcessor(image_size=1024)
    use_im_start_end = True
    image_token_len = 256
    image = load_image(img_np)
    w, h = image.size
    if type == 'format':
        qs = 'OCR with format: '
    else:
        qs = 'OCR: '


    if use_im_start_end:
        qs = DEFAULT_IM_START_TOKEN + DEFAULT_IMAGE_PATCH_TOKEN*image_token_len + DEFAULT_IM_END_TOKEN + '\n' + qs
    else:
        qs = DEFAULT_IMAGE_TOKEN + '\n' + qs


    conv_mode = "mpt"
    args.conv_mode = conv_mode

    conv = conv_templates[args.conv_mode].copy()
    conv.append_message(conv.roles[0], qs)
    conv.append_message(conv.roles[1], None)
    prompt = conv.get_prompt()

    # print(prompt)

    inputs = tokenizer([prompt])

    image_1 = image.copy()
    image_tensor = image_processor(image)


    image_tensor_1 = image_processor_high(image_1)

    if device == 'cpu':
        input_ids = torch.as_tensor(inputs.input_ids).cpu()
    else:
        input_ids = torch.as_tensor(inputs.input_ids).cuda()

    stop_str = conv.sep if conv.sep_style != SeparatorStyle.TWO else conv.sep2
    keywords = [stop_str]
    stopping_criteria = KeywordsStoppingCriteria(keywords, tokenizer, input_ids)
    streamer = TextStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)


    with torch.autocast(device, dtype=torch.bfloat16):
        if device == 'cpu':
            images = [(image_tensor.unsqueeze(0).half().cpu(), image_tensor_1.unsqueeze(0).half().cpu())]
        else:
            images = [(image_tensor.unsqueeze(0).half().cuda(), image_tensor_1.unsqueeze(0).half().cuda())]
        output_ids = model.generate(
            input_ids,
            images= images,
            do_sample=False,
            num_beams = 1,
            no_repeat_ngram_size = 20,
            streamer=streamer,
            max_new_tokens=4096,
            stopping_criteria=[stopping_criteria]
            )
        outputs = tokenizer.decode(output_ids[0, input_ids.shape[1]:]).replace('<|im_end|>','')
        ocr_result = processing(outputs)
        return ocr_result
        
def ocr_detection(img):
    if len(img.shape) == 3:  
        height, width, _ = img.shape
    elif len(img.shape) == 2: 
        height, width = img.shape
    else:
        raise ValueError("Invalid image format")

    x_start, y_start = width // 2, 0  
    x_end = width  
    y_end = 100 
    
    if img is None:
        print(f"Error loading image {img}. Skipping.")
    roi = img[y_start:y_end, x_start:x_end]

    return roi

if __name__ == "__main__":
    model_name =  "/home/huzefaanver/Desktop/LSM repo 2/ocr_in_lsm/GOT_weights/GOT_weights"
    # image = cv2.imread("/home/huzefaanver/Desktop/LSM repo 2/ocr_in_lsm/test_images/1.png")
    video_path = '/home/huzefaanver/Desktop/LSM repo 2/ocr_in_lsm/GOT-OCR2/videos/video_1.mp4'
    # video_path = '/home/huzefaanver/Desktop/LSM repo 2/ocr_in_lsm/videos/video_1.mp4'

    parser = argparse.ArgumentParser()
    parser.add_argument("--box", type=str, default= '')
    parser.add_argument("--color", type=str, default= '')
    parser.add_argument("--render", action='store_true')
    # parser.add_argument("--device", type=str, default='cuda')
    args = parser.parse_args()

    type = "ocr"
    device = "cpu"
    disable_torch_init()
    model_name = os.path.expanduser(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)
    device = device
    model = GOTQwenForCausalLM.from_pretrained(model_name, low_cpu_mem_usage=True, device_map=device, use_safetensors=True, pad_token_id=151643).eval()
    model.to(device=device,  dtype=torch.bfloat16)

    cap = cv2.VideoCapture(video_path)

    if not cap.isOpened():
        print(f"Error: Could not open video file at {video_path}.")
        exit(1) 

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame = cv2.resize(frame, (640,640))
        frame = ocr_detection(frame)
        ocr_result = eval_model(args, model, frame, type, device)
        print("OCR Result:", ocr_result)
        cv2.imshow('Video Frame', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()
